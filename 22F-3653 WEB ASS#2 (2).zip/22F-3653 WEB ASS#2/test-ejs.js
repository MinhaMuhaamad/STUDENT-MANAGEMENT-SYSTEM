const ejs = require('ejs'); console.log('EJS version:', ejs.VERSION);
